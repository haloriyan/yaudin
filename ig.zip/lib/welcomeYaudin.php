<style>
	body { color: #454545; }
	h3 {
		font-size: 40px;
		font-family: OBold;
	}
	.icon {
		font-size: 85px;
		font-family: Billabong;
	}
	p { font-size: 22px; }
</style>
<div class="rata-tengah">
	<div class="icon">Y</div>
	<h3>Selamat Datang di Yaudin</h3>
	<p>
		Ikuti seseorang dan kiriman mereka akan muncul disini
	</p>
</div>