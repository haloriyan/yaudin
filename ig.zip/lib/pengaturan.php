<?php
include '../ig.php';

$sesi = $ig->cekSesi();
$nama = $ig->getUser($sesi, "nama");
$email = $ig->getUser($sesi, "email");
$bio = $ig->getUser($sesi, "bio");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale = 1">
	<title>Pengaturan | Yaudin</title>
	<link href="fw/build/fw.css" rel="stylesheet">
	<link href="fw/build/font-awesome.min.css" rel="stylesheet">
	<link href="inc/css/style.setting.css" rel="stylesheet">
	<script src="inc/js/jquery-3.1.1.js"></script>
	<script src="inc/js/script.setting.js"></script>
	<style>
		.box { width: 92%; }
	</style>
</head>
<body>

<div class="atas">
	<h1 class="judul rata-tengah">Yaudin</h1>
</div>

<div class="container">
	<div class="bagian" id="umum">
		<div class="wrap">
			<h2>Setelan Umum</h2>
			<form>
				<div class="isi">Nama :</div>
				<input type="text" class="box" id="namaSet" value="<?php echo $nama; ?>">
				<div class="isi">E-Mail :</div>
				<input type="email" class="box" id="mailSet" value="<?php echo $email; ?>">
				<div class="isi">Bio :</div>
				<textarea class="box" id="bioSet"><?php echo $bio; ?></textarea>
				<div class="bag-tombol">
					<button class="tbl biru" id="saveUmum"><i class="fa fa-save"></i> SIMPAN</button>
				</div>
			</form>
		</div>
	</div>
	<div class="bagian" id="secure">
		<div class="wrap">
			<h2>Keamanan</h2>
			<form>
				<input type="hidden" id="sandiLamaHide" value="<?php echo $sandi; ?>">
				<div class="isi">Kata sandi lama :</div>
				<input type="password" class="box" id="pwdLama">
				<div class="isi">Buat sandi baru :</div>
				<input type="password" class="box" id="pwdBaru">
				<div class="isi">Ulangi kata sandi :</div>
				<input type="password" class="box" id="retypePwd">
				<div class="bag-tombol">
					<button class="tbl biru" id="saveSecure"><i class="fa fa-save"></i> UBAH</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="bg"></div>
<div class="popupWrapper" id="notif">
	<div class="popup">
		<div class="wrap">
			<h2>Notice</h2>
			<p>Setelan berhasil diubah</p>
		</div>
	</div>
</div>

</body>
</html>