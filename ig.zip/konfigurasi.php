<?php

## KONFIGURASI DATABASE

$db['host'] = "localhost";
$db['user'] = "root";
$db['pass'] = "";
$db['namaDb'] = "ig";

## KONFIGURASI TOKO
$konfig['url'] = "http://localhost/ig";